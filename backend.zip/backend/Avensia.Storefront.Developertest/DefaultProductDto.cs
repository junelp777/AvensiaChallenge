﻿using System.Collections.Generic;
namespace Avensia.Storefront.Developertest
{
    public class DefaultProductDto //: IProductDto
    {

        string Id { get; set; }
        string Name { get; set; }
        decimal Price { get; set; }

    }
}